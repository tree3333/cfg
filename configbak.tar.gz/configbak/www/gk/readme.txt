http://iddc.cc:8002/gk/
local http://192.168.10.3:/gk


