#!/bin/sh /etc/rc.common
# Enable RPS (Receive Packet Steering)

START=21

start() {
	. /lib/rps.sh
	
	rsfe=32768
	sysctl -w net.core.rps_sock_flow_entries=$rsfe

	dev_name=$(cat /etc/product_info | awk -F "=" '$1=="PRODUCT_STD_NAME" {print $2}')

	boardname=$(. /lib/board.sh; sys_board_name)
	if [ "$boardname" = "MT7621" ]; then
		irqnum=$(cat /proc/interrupts | grep eth0 | awk -F: '{print $1}' | sed 's/^ *//')
		echo "4"  > /proc/irq/$irqnum/smp_affinity
	elif [ "$boardname" = "mt7621-rfb-ax-nor" ]; then
		irqnum=$(cat /proc/interrupts | grep ethernet | awk -F: '{print $1}' | sed 's/^ *//')
		echo "4"  > /proc/irq/$irqnum/smp_affinity
	fi

	devices=$(ls /sys/class/net/)
	devices=$(echo -n $devices)
	for dev in $devices; do
		if [ "$dev_name" = "S3A" -o "$dev_name" = "RE105GW" -o "$dev_name" = "GC-RE105GW" -o "$dev_name" = "GC-RX1800GW" ]; then
			if [ "$(echo "$dev" | grep -E "eth|br-lan")" = "$dev" ]; then
				set_rps $dev
			fi
		else
			if [ "$(echo "$dev" | grep -E "eth|br-lan|wwan")" = "$dev" ]; then
				set_rps $dev
			fi
		fi
	done
	
	set_msix_affinity
}
