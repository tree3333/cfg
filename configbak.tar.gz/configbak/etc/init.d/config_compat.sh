#!/bin/sh /etc/rc.common
# author: ght@2020.09.08 copyright www.gocloud.cn

START=20

debug_file=/etc/compat.debug

start() {
	boardname=$(. /lib/board.sh; sys_board_name)
	if [ "$boardname" != "X86" ]; then
		return
	fi
	
	###for wwws free version
	if [ -f /rom/lib/sx2000_free_ver ]; then
		sed -i "s/PRODUCT_NAME=SX2000/PRODUCT_NAME=SX2001/g" /etc/product_info
	fi
	########################
	
	mtd_section=$(cat /proc/mtd | grep panic_dump | awk -F ':' '{print $1}')
	if [ "$mtd_section" = "" ]; then
		return
	fi
	
	if [ -f /lib/backup ]; then
		### now copy config files to panicdump 
		echo  Now try to copy config files to panicdump section $mtd_section >> $debug_file

		backup_dir=/tmp/backup_dir

		mkdir -p $backup_dir

		sed -i '/tnmp\/image/d'  /etc/sysupgrade.conf
		sysupgrade -b ${backup_dir}/backup
		cd $backup_dir
		tar zxvf backup
		rm -rf backup
		rm -rf etc/config/product_params
		rm -rf etc/config/luci

		touch etc/need_restore

		tar zcvf backup etc www 
		dd if=./backup of=/dev/${mtd_section}
		echo "Backup ok" >> $debug_file
		cd /

	else
		
		if [ -f /lib/restore ]; then
			### now copy config files from panicdump 
			
			echo now try to copy config files from panicdump section $mtd_section >> $debug_file
			backup_dir=/tmp/backup_dir

			mkdir -p $backup_dir

			dd if=/dev/${mtd_section} of=${backup_dir}/backup

			cd $backup_dir
			tar zxvf backup
			
			rm -rf backup
			rm -rf etc/config/luci
			rm -rf etc/config/product_params

			[ -f etc/need_restore ] && {
				echo Now restore config files from panicdump section $mtd_section >> $debug_file

				rm -rf ${backup_dir}/etc/need_restore

		        	cp -fpR ${backup_dir}/* /

				uci set luci.main.wizards=0
				uci commit luci

				rm -rf /lib/restore

				echo "Restore ok. Now clean $mtd_section ..." >> $debug_file
				dd if=/dev/zero of=/dev/${mtd_section}


				echo "Cleaning done. Now Reboot ..." >> $debug_file
				reboot
			}

			cd /
				
	
		else
			echo "Do nothing" >> $debug_file
		fi
	fi
	
}
