

local http = require 'httpx'
local tasklet = require 'tasklet'
local uci = require 'uci'

local M = {}
local THE_RESP = {
	err = 0,
	data = 0,
}

--[[
输出分3种情况
1. 初始状态，此时可选择创建网络(依赖can_create)或者加入网络
{
	state: 'blank'
	can_create: true|false  -- 是否具有创建网络的功能
}
给创建按钮和加入按钮， 分别访问sdwan/create, sdwan/join
2. 已加入
{
	state: 'joined',
	name: '<name>', // 网络名称
}
给退出按钮，访问sdwan/secede
3. 已创建
{
	state: 'created'
	type: 1|3|4, // 星型， 反向星型，双向星型
	token:  // 网络token， 默认****显示
	edges: [  // 节点列表
		{
			vlanip = '10.10.10.2',
			sn = 'GC0001321RE123',
			mac = <mac>,
			strlans = '192.168.1.1,192.168.2.1',
			online = true|false,
		},
		...
	]
}
列表行里面给删除设备按钮  sdwan/deldev
列表上方给删除网络按钮 sdwan/destroy
]]
function M.nosandbox__home()
	local cursor = uci.cursor()
	local sdwan = cursor:get('n2n', 'global', 'sdwan')
	local resp = {
		state = 0,
	}
	if not sdwan then
		resp.state = 'blank'
		resp.can_create = fs.isreg('/usr/lib/lua/n2n.so')

	elseif sdwan == 'myself' then
		resp.state = 'created'
		resp.type = tonumber(cursor:get('n2n', 'global', 'type'))
		resp.token = cursor:get('n2n', 'global', 'token')
		http.ajax({
			url = 'http://127.0.0.1:17218/edges',
			type = 'get',
			async = false,
			timeout = 3,
			data_type = 'json',
			success = function (v)
				resp.edges = v.data
			end,
			error = function ()
				resp.edges = NULL
			end,
		})

	else
		resp.state = 'joined'
		resp.name = sdwan
	end
	return resp
end

--[[ 加入
输入 {
	name:  // 固定IP,序列号,动态域名
	token:
}
输出 {
	err:
	[data:]  -- 当err=conflicted时，为冲突设备的序列号，特殊值"sdwan"表示和组网网段冲突
}
]]
function M.join(_, params)
	local cursor = uci.cursor()
	if cursor:get('n2n', 'global', 'enable') == '1' then
		THE_RESP.err = 'existed'
		return THE_RESP
	end

	local sdwan = params.name
	os.execute('lua /usr/share/sdwan/sdwan.lua --server="' .. sdwan .. '" --token="' .. params.token .. '"')
	cursor = uci.cursor()
	THE_RESP.err = cursor:get('n2n', 'global', 'sdwan_err')
	if THE_RESP.err == 'conflicted' then
		THE_RESP.data = cursor:get('n2n', 'global', 'sdwan_errobj')
	else
		THE_RESP.data = false
	end
	return THE_RESP
end

-- 退出
function M.secede()
	os.execute('/etc/init.d/sdwan stop')
	os.execute('lua /usr/share/sdwan/sdwan.lua --secede')
	local cursor = uci.cursor()
	local err = cursor:get('n2n', 'global', 'enable')
	if err ~= '0' then
		os.execute('/etc/init.d/sdwan stop')
		os.execute('/etc/init.d/n2n stop')
		file_put_content('/etc/config/n2n', [[
	config global 'global'
		option 'enable' '0'
]])
	end
	THE_RESP.err = 'ok'
	THE_RESP.data = false
	return THE_RESP
end

local lans
local lans_mtime = 0
local function update_lans()
	if tasklet.now - lans_mtime > 120 then
		local cursor = uci.cursor()
		local t = cursor:get_all('network')
		lans = {}
		for name, iface in pairs(t) do 
			if name:match('^lan') then
				local ip = iface.ipaddr
				if ip and ip:is_ipv4() then
					table.insert(lans, ip)
				end
			end
		end
		lans_mtime = tasklet.now
	end
end

--[[
显示创建网络表单前先 获取一个动态分配的IP网段
输出 {
	err:
	data: '10.10.10',	
}
]]
function M.allocipseg()
	update_lans()
	local lansegset = {}
	for _, lan in ipairs(lans) do 
		lansegset[lan:match('^(%d+%.%d+%.%d+)')] = 1
	end
	for i = 10, 254 do 
		local lanseg = '10.10.' .. i
		if not lansegset[lanseg] then
			THE_RESP.err = 'ok'
			THE_RESP.data = lanseg
			return THE_RESP
		end
	end
	THE_RESP.err = 'internal'
	THE_RESP.data = false
	return THE_RESP
end

--[[
提交创建网络
输入 {
	ipseg: // '10.10.10'
	type: // 1|3|4
}
输出 {
	err: // 
	data: // token，当err='ok' 
}
]]
function M.create(_, params)
	local ipseg = params.ipseg
	local klass = tonumber(params.type)
	THE_RESP.data = false

	if not ipseg or not ipseg:match('^%d+%.%d+%.%d+$') then
		THE_RESP.err = 'invalidarg-ipseg'
		return THE_RESP
	end
	if klass ~= 1 and klass ~= 3 and klass ~= 4 then
		THE_RESP.err = 'invalidarg-type'
		return THE_RESP
	end

	local cursor = uci.cursor()
	if cursor:get('n2n', 'global', 'sdwan') then
		THE_RESP.err = 'existed'
		return THE_RESP
	end

	update_lans()
	local lansegset = {}
	for _, lan in ipairs(lans) do 
		lansegset[lan:match('^(%d+%.%d+%.%d+)')] = 1
	end
	if lansegset[ipseg] then
		THE_RESP.err = 'conflicted'
		return THE_RESP
	end

	local token = md5(math.floor(tasklet.now_unix) .. K.SERIAL):sub(1, 15)
	cursor:set('n2n', 'global', 'community', 'sdwan')
	cursor:set('n2n', 'global', 'token', token)
	cursor:set('n2n', 'global', 'type', klass)
	cursor:set('n2n', 'global', 'nr_peers', '1')
	cursor:set('n2n', 'global', 'ipaddr', ipseg .. '.1')
	cursor:set('n2n', 'global', 'enable', '1')
	cursor:set('n2n', 'global', 'core_lanip', table.concat(lans, ','))
	cursor:set('n2n', 'global', 'sdwan', 'myself')
	cursor:commit('n2n')
	http.ajax({
		url = 'http://' .. K.WEBSERVER .. '/user.php?s=/Agent/Public/sdwan&action=create&sn=' .. K.SERIAL,
		type = 'post',
		async = true,
		timeout = 15,
		data_type = 'json',
		success = dummy,
		error = dummy,
	})
	os.execute('/etc/init.d/sdwan start')
	THE_RESP.data = token
	THE_RESP.err = 'ok'
	return THE_RESP
end

--[[ 删除设备
输入 {
	sn: 
}
]]
function M.nosandbox__deldev(_, params)
	local err = 'internal'
	http.ajax({
		url = 'http://127.0.0.1:17218/edges/delete?sn=' .. params.sn,
		type = 'post',
		async = false,
		timeout = 3,
		data_type = 'json',
		success = function (resp)
			err = resp.err
		end,
		error = dummy,
	})
	THE_RESP.err = err
	THE_RESP.data = false
	return THE_RESP
end

-- 销毁网络
function M.nosandbox__destroy()
	local err = 'internal'
	http.ajax({
		url = 'http://127.0.0.1:17218/destroy',
		type = 'post',
		async = false,
		timeout = 3,
		data_type = 'json',
		success = function (resp)
			err = resp.err
		end,
		error = dummy,
	})
	if err == 'ok' then
		http.ajax({
			url = 'http://' .. K.WEBSERVER .. '/user.php?s=/Agent/Public/sdwan&action=destroy&sn=' .. K.SERIAL,
			type = 'post',
			async = true,
			timeout = 15,
			data_type = 'json',
			success = dummy,
			error = dummy,
		})
	end
	THE_RESP.err = err
	THE_RESP.data = false
	return THE_RESP
end

return M
