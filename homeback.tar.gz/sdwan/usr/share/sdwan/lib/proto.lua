
local zlib = require 'zlib'
local cjson = require 'cjson'

local pcall, type, tonumber = pcall, type, tonumber

local POOL_MAXNUM = K.POOL_MAXNUM or 100
local arr = table.array(POOL_MAXNUM)
local nr_idle = 0
local idx_head = 1
local idx_tail = 1

local function getbuf()
	local buf 
	if nr_idle > 0 then
		nr_idle = nr_idle - 1
		buf = arr[idx_head]
		arr[idx_head] = 0
		idx_head = idx_head + 1
		if idx_head > POOL_MAXNUM then
			idx_head = 1
		end
	else
		buf = buffer.new()
	end
	return buf
end
K.getbuf = getbuf

local function putbuf(buf)
	if nr_idle < POOL_MAXNUM then
		arr[idx_tail] = buf:reset()
		nr_idle = nr_idle + 1
		idx_tail = idx_tail + 1
		if idx_tail > POOL_MAXNUM then
			idx_tail = 1
		end
	end
end
K.putbuf = putbuf

-- 读取一个msg。 若body有效则为buffer， 使用完后必须使用putbuf释放。
function K.proto_recvmsg(ch_sock)
	local line, err = ch_sock:read()
	if not line then
		return nil, err
	end
	
	local ok, msg = pcall(cjson.decode, line)
	if type(msg) ~= 'table' then
		return line, -1
	end
	
	local bodysize = tonumber(msg.bodysize) or 0
	if bodysize > 0 then
		local bodybuf = pool.getbuf()
		while bodysize > 0 do 
			local rd, err = ch_sock:read(bodysize)
			if not rd then
				pool.putbuf(bodybuf)
				return nil, err
			end
			bodybuf:putreader(rd)
			bodysize = bodysize - #rd
		end
		if msg.compressed then
			zlib.decompress(bodybuf)
		end
		msg.body = bodybuf
	end
--print('RECVMSG <<<') dump(msg)
	return msg, 0
end

-- 发送一个msg。body可以是string/buffer/reader/table, 如果是table则自动json-encode(可能会compress)；
-- 如果是buffer则发送后自动调用putbuf。
function K.proto_sendmsg(ch_sock, msg)
--print('>>> SENDMSG') dump(msg)
	local body = msg.body
	local isstr, isbuf
	local cb_unref
	
	if body then
		cb_unref = msg.cb_unref
		if cb_unref then
			msg.cb_unref = nil
		end
		local tbody = type(body)
		if tbody == 'string' then
			isstr = true
		elseif tbody == 'table' then
			local buf = getbuf()
			cjson.encodeb(body, buf)
			--[[
			if #buf > 4096 then
				zlib.compress(buf)
			end
			]]
			isbuf = true
			body = buf
		else
			isbuf = body.putc
		end
		msg.bodysize = #body
		msg.body = nil
	end
	
	local buf = getbuf()
	cjson.encodeb(msg, buf:rewind())
	buf:putstr('\n')
	if isstr then
		buf:putstr(body)
	end
	err = ch_sock:write(buf)
	putbuf(buf)
	
	if body and not isstr then
		if err == 0 then
			err = ch_sock:write(body)
		end
		if isbuf then
			putbuf(body)
		end
	end
	if cb_unref then
		cb_unref()
	end
	return err	
end

