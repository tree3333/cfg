
--[[

]]

local cjson = require 'cjson'
local log = require 'log'
local tasklet = require 'tasklet'
local uci = require 'uci'

local pairs, ipairs = pairs, ipairs
local type, tonumber, tostring = type, tonumber, tostring

local K, V = K, V

local conf = {
    klass = 0, 
    token = 0, 
    ipseg = 0, 
    nrdevs= 0, 
    sn2dev = {}
}
V.conf = conf
local thisdev
local devs = table.array(K.MAX_NRDEVS)   -- indexed by ip suffix

local function load()
    local cursor = uci.cursor()
    conf.klass = tonumber(cursor:get('n2n', 'global', 'type'))
    conf.token = cursor:get('n2n', 'global', 'token')
    K.TOKEN = conf.token
    conf.ipseg = cursor:get('n2n', 'global', 'ipaddr'):match('(%d+%.%d+%.%d+)')
    conf.nrdevs = tonumber(cursor:get('n2n', 'global', 'nr_peers'))
    if not conf.klass or not conf.token or not conf.ipseg or not conf.nrdevs or conf.nrdevs < 1 then
        return false
    end

    local sn2dev = conf.sn2dev
    local strlans = cursor:get('n2n', 'global', 'core_lanip')
    thisdev = {
        sn = K.SERIAL,
        ipsuffix = 1,
        ip = conf.ipseg .. '.1',
        lans = strlans:tokenize(','),
        strlans = strlans,
    }
    sn2dev[K.SERIAL] = thisdev
    for i = 1, conf.nrdevs - 1 do 
        local ip = cursor:get('n2n', 'global', 'peer' .. i .. '_vlanip')
        local strlans = cursor:get('n2n', 'global', 'peer' .. i .. '_lanip')
        local sn = cursor:get('n2n', 'global', 'peer' .. i .. '_sn')
        if not ip or not strlans or not sn then
            return false
        end
        sn2dev[sn] = {
            ip = ip,
            strlans = strlans,
            lans = strlans:tokenize(','),
            ipsuffix = tonumber(ip:match('(%d+)$')),
            sn = sn,
        }
    end
    for _, dev in pairs(sn2dev) do 
        devs[dev.ipsuffix] = dev
    end
    conf.thisdev = thisdev
    return true
end
if not load() then
    log.fatal('uci configuration corrupted')
end

local function save() 
    local cursor = uci.cursor()
	cursor:set('n2n', 'global', 'nr_peers', conf.nrdevs)
    local idx = 1
    for sn, dev in pairs(conf.sn2dev) do 
        if sn ~= K.SERIAL then
            cursor:set('n2n', 'global', 'peer' .. idx .. '_vlanip', dev.ip)
            cursor:set('n2n', 'global', 'peer' .. idx .. '_sn', sn)
            local strlans = dev.strlans
            if not strlans then
                strlans = table.concat(dev.lans, ',')
                dev.strlans = strlans
            end
            cursor:set('n2n', 'global', 'peer' .. idx .. '_lanip', strlans)
            idx = idx + 1
        end
    end
    cursor:commit('n2n')
end

-- 星型网络检查lan冲突性: 该分支的lan网段 必须和  (中心节点的lan网段, 组网网段)各异
-- 反向(和双向)星型检查lan冲突性: 该分支的lan网段 必须和  (其他分支lan网段，中心节点lan网段, 组网网段)各异
local function lans_conflictedwith(klass, lans)
    local ipsegset = {
        [conf.ipseg] = 'vlan',
    }
    if klass == K.VLAN_KLASS_STAR then
        for _, lan in ipairs(thisdev) do 
            ipsegset[lan:match('(%d+%.%d+%.%d+)')] = thisdev.sn
        end
    else
        for sn, dev in pairs(conf.sn2dev) do 
            for _, lan in ipairs(dev.lans) do 
                ipsegset[lan:match('(%d+%.%d+%.%d+)')] = sn
            end
        end
    end
    for _, lan in ipairs(lans) do 
        local lanseg = lan:match('(%d+%.%d+%.%d+)')
        local sn = ipsegset[lanseg]
        if sn then
            return sn
        end
    end
end

local function cmdroutes(op, vlanip, lans)
    local buf = tmpbuf:rewind()
    for _, lan in ipairs(lans) do 
        local lanseg = lan:match('(%d+%.%d+%.%d+)')
        if lanseg then
            local cmd = buf:putstr('route ', op, ' -net ', lanseg, '.0 netmask 255.255.255.0 gw ', vlanip, ' n2n'):str()
            log.info('executing -> ', cmd)
            os.execute(cmd)
        end
    end
end

function K.conf_adddev(sn, lans)
    if conf.nrdevs == K.MAX_NRDEVS then
        return 'toomany'
    end

    local klass = conf.klass
    local conflicted_sn = lans_conflictedwith(klass, lans)
    if conflicted_sn then
        return 'conflicted', conflicted_sn
    end

    local ipsuffix
    for i = 1, K.MAX_NRDEVS do 
        if not devs[i] then
            ipsuffix = i
            break
        end
    end
    local dev = {
        sn = sn,
        ipsuffix = ipsuffix,
        ip = conf.ipseg .. '.' .. ipsuffix,
        lans = lans,
        strlans = false,
    }
    conf.nrdevs = conf.nrdevs + 1
    conf.sn2dev[sn] = dev
    devs[ipsuffix] = dev
    save()

    if klass == K.VLAN_KLASS_RSTAR or klass == K.VLAN_KLASS_DSTAR then
	    cmdroutes('add', dev.ip, lans)
	end
end

function K.conf_rmdev(sn)
    if sn == K.SERIAL then
        return 'forbidden'
    end
    local dev = conf.sn2dev[sn]
    if not dev then
        return 'notfound'
    end

    conf.sn2dev[sn] = nil
    devs[dev.ipsuffix] = false
    conf.nrdevs = conf.nrdevs - 1
    save()

    if conf.klass == K.VLAN_KLASS_RSTAR or conf.klass == K.VLAN_KLASS_DSTAR then
	    cmdroutes('del', dev.ip, dev.lans)
	end
end

function K.conf_destroy()
    conf.nrdevs = 0

    local idx = 1
    local buf = tmpbuf:rewind()
    for sn, dev in pairs(conf.sn2dev) do 
        if sn ~= K.SERIAL then
            for _, lan in ipairs(dev.lans) do 
                local lanseg = lan:match('(%d+%.%d+%.%d+)')
                if lanseg then
                    local cmd = buf:putstr('route del -net ', lanseg, '.0 netmask 255.255.255.0 gw ', vlanip, ' n2n'):str()
                    log.info('executing -> ', cmd)
                    os.execute(cmd)
                end
            end
            idx = idx + 1
        end
    end
    file_put_content('/etc/config/n2n', [[
    config global 'global'
    	option 'enable' 0
]])
end

local function init()

end

return init
