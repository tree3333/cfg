
local tasklet = require 'tasklet'
local http = require 'httpd'
local cjson = require 'cjson'
local routes = require('urlroutes')()
R.http = routes

local SERIAL = K.SERIAL

local function check_acl(req)
	local conn = tasklet.current_task()
	if conn.addr ~= '127.0.0.1' then
		local parasm = req.params
		local timestamp = tonumber(params.timestamp)
		local token = params.token
		local now = math.floor(tasklet.now_unix)
		
		if not timestamp or not token then
			return 'invalid'
		end
		if now - timestamp < -1800 or now - timestamp > 1800 then
			return 'expired'
		end
		if md5(timestamp .. 'sdwan') ~= token then
			return 'forbidden'
		end
	end
end


-- 获取程序运行状态
local st = {
	ts_born = tasklet.now,
	age = 0,
	sz_luamemMB = 0,
	sz_stdmemMB = 0,
	nr_buffers = 0,
	nr_readers = 0,
}
routes.get['/status'] = function ()
	local sec = math.floor(tasklet.now - st.ts_born)
	local buf = tmpbuf:rewind()
	st.age = sec
	st.sz_luamemMB = math.floor(collectgarbage('count') / 1024)
	local a, b, c = stdmem()
	st.sz_stdmemMB = a % 1048576
	st.nr_buffers = b
	st.nr_readers = c
	return st
end

-- 获取节点实时详情
local stedge = {
	vlanip = 0,
	sn = 0,
	mac = 0,
	online = 0,
}
routes.get['/edges'] = function (req)
	local err = check_acl(req)
	if err then
		return err
	end

	local buf = tmpbuf:rewind():putstr('{"err":"ok", "data":[')
	local sn2edge = V.sn2edge
	local nr = 0
	for sn, dev in pairs(V.conf.sn2dev) do 
		stedge.sn = sn
		stedge.vlanip = dev.ip
		stedge.lans = dev.strlans
		local edge = sn2edge[sn]
		if edge then
			stedge.online = true
			stedge.mac = edge.mac
		else
			stedge.online = sn == SERIAL
			stedge.mac = '-'
		end
		if nr > 0 then
			buf:putstr(',')
		end
		cjson.encodeb(stedge, buf)
		nr = nr + 1
	end
	buf:putstr(']}')
	http.set_content_type('application/json')
	http.header('Access-Control-Allow-Origin', '*')
	http.echo(buf:str())
end

-- 诊断网络状态(内网网段冲突性)
routes.post['/diag'] = function (req)

end

-- 删除节点
routes.post['/edges/delete'] = function (req)
	local sn = req.params.sn
	if not sn then
		return 'invalidarg-sn'
	end
	local err = K.conf_rmdev(sn)
	if err then
		return err
	end
	
	local client = V.sn2client[sn]
	if client then
		tasklet.start_task(function ()
			client.request({
				type = 'del'
			})
		end)
	end
	return 'ok'
end

-- 删除整个网络
routes.post['/destroy'] = function (req)
	K.conf_destroy()
	tasklet.start_task(function ()
		for _, c in pairs(V.sn2client) do 
			c.request({
				type = 'del',
			})
		end
		tasklet.sleep(3)
		os.execute('/etc/init.d/n2n stop')
		os.exit(0)
	end)
	return 'ok'
end

local function init()	
	http.start_server({
		addr = '0.0.0.0', 
		port = K.HTTP_PORT,
		routes = routes,
	})
end

return init

