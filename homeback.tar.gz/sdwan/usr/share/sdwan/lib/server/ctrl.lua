


local cjson = require 'cjson'
local tasklet = require 'tasklet.channel.message'
local log = require 'log'
local uci = require 'uci'

local K, V = K, V
local getsockname = socket.getsockname

-- inited in init() {
local conf  
local myip
-- }

local reqhandlers = {}
R.ctrl = reqhandlers

local sn2client = {}
V.sn2client = sn2client


local function update_sdwanip(fd)
	local mynewip, _, _ = getsockname(fd)
	if mynewip and mynewip:is_ipv4() and myip ~= mynewip then
		myip = mynewip
		local cursor = uci.cursor()
		cursor:set('n2n', 'global', 'sdwan_ip',  myip)
		cursor:commit('n2n')
		if os.fork() == 0 then
			os.closerange(0, 64)
			os.execute('/etc/init.d/n2n restart')
			os.exit(0)
		end
	end
end

local function client_loop(fd, ip, port)
	local ch_sock = tasklet.stream_channel.new(fd)
	local req_head, req_tail = false, false
	local resp_head, resp_tail = false, false
	local seq2req = {}
	local seq, nr_reqnoresp, nr_requnsent = 1, 0, 0
	local wait4resp_head, wait4resp_tail = false, false
	local nr_wait4resp = 0
	local sendmsg_task, expire_task
	local c

	-- 请求req， 不阻塞当前task， 成功后调用cb(c, resp)， 失败不会调用
	local function request_async(req, cb, sec)
		local now = tasklet.now
		req._wdeadline = now + (sec or K.CTRL_REQUEST_TIMEDOUT)
		if cb then
			req._wcb = cb
			req.seq = seq 
		else
			req.seq = -seq 
		end
		seq = seq + 1
		if req_tail then
			req_tail._wnext = req
			req_tail = req
		else
			req_head = req
			req_tail = req
			tasklet.kill_task(sendmsg_task)
		end
	end

	local function request(req, sec)
		local task = tasklet.current_task()
		local ret
		sec = sec or K.CTRL_REQUEST_TIMEDOUT

		local function cb(c, resp)
			ret = resp
			tasklet.kill_task(task, 0)
		end

		request_async(req, cb, sec)
		tasklet.sleep(sec)
		return ret
	end
	
	local function reply(resp)
		local now = tasklet.now
		resp._wdeadline = now + 3   -- response限定5s内发送完成
		if resp_tail then
			resp_tail._wnext = resp
			resp_tail = resp
		else
			resp_head = resp
			resp_tail = resp
			tasklet.kill_task(sendmsg_task)
		end
	end
	
	local function send_queue(msg)
		local now = tasklet.now
		local err = 0
		
		while msg do
			local next = msg._wnext
			local deadline = msg._wdeadline
			
			if now > deadline then
				local body = msg.body
				if type(body) == 'userdata' then
					K.putbuf(body)
				end
				nr_requnsent = nr_requnsent + 1
			else
				local cb = msg._wcb
				msg._wdeadline = nil
				msg._wnext = nil
				msg._wcb = nil
				err = K.proto_sendmsg(ch_sock, msg)
				if err ~= 0 then
					break
				end

				if cb then
					if wait4resp_tail then
						wait4resp_tail._wnext = msg
						msg._wprev = wait4resp_tail
						wait4resp_tail = msg
					else
						wait4resp_head = msg
						wait4resp_tail = msg
						msg._wprev = false
					end
					nr_wait4resp = nr_wait4resp + 1
					seq2req[msg.seq] = msg
					msg._wcb = cb
					msg._wdeadline = deadline
				end
				msg.body = false
			end
			
			msg = next
		end
		return err
	end
		
	local function sendmsg_taskentry()
		local err = 0
		while true do
			local req, resp = req_head, resp_head
			req_head, req_tail = false, false
			resp_head, resp_tail = false, false
			
			if req then
				err = send_queue(req)
				if err ~= 0 then
					break
				end
			end
			
			if resp then
				err = send_queue(resp)
				if err ~= 0 then
					break
				end
			elseif not req then
				tasklet.sleep(1)
			end
		end
		log.error('ctrl client(', c.sn, ') send error -> ', err)
		ch_sock:close()
	end
	
	local function expirereq_taskentry()
		local sleep = tasklet.sleep
		while true do
			sleep(0.5)

			local now = tasklet.now
			local req = wait4resp_head
			local nr_expired = 0
			while req do 
				if now < req._wdeadline then
					break
				end
				nr_expired = nr_expired + 1
				seq2req[req.seq] = nil
				req = req._wnext
			end
			if nr_expired > 0 then
				nr_reqnoresp = nr_expired + nr_reqnoresp
				nr_wait4resp = nr_wait4resp - nr_expired
				wait4resp_head = req
				if req then
					req._wprev = false
				else
					wait4resp_tail = false
				end
			end
		end
	end

	local function handle_login(msg)
		local resp = {
			err =  'ok',
			seq = msg.seq
		}
		local token, sn = msg.token, msg.sn
		if not sn then
			resp.err = 'invalidarg-sn'
		elseif msg.secede then
			K.conf_rmdev(sn)
			resp.err = 'deleted'
			c = {
				sn = sn,
			}
		elseif not token then
			resp.err = 'invalidarg-token'
		elseif token ~= conf.token then
			resp.err = 'unauthenticated'
		else
			c = {
				ch_sock = ch_sock,
				sn = sn,
				ip = ip,
				port = port,
				ts_born = msg.ts_born or tasklet.now_unix,
				ts_active = tasklet.now,
				
				-- 导出的函数 
				request = request, 
				request_async = request_async, 
			}
			sn2client[sn] = c
	
			local devconf = conf.sn2dev[sn]
			local lans = msg.lans
			if lans then
				if not devconf then
					local err, errobj = K.conf_adddev(sn, lans)
					if err then
						resp.err = err
						resp.errobj = errobj
					else
						devconf = conf.sn2dev[sn]
					end
				end
				if devconf then
					resp.vlantype = conf.klass
					resp.ip = devconf.ip
					resp.core_ip = conf.thisdev.ip
					resp.core_strlans = conf.thisdev.strlans
				else
					resp.err = 'internal'
				end
			else
				if not devconf then
					resp.err = 'deleted'
				end
			end
		end
		reply(resp)
		log.info('ctrl-client ', sn, ' login finished, err=', resp.err)
		if resp.err == 'ok' then
			update_sdwanip(fd)
		end
	end
	
	local function handle_response(resp)
		local seq = resp.seq
		if seq < 0 then
			return
		end

		local req = seq2req[seq]
		if not req then
			return
		end
		local prev, next = req._wprev, req._wnext
		if next then
			next._wprev = prev
		else
			wait4resp_tail = prev
		end
		if prev then
			prev._wnext = next
		else
			wait4resp_head = next
		end
		nr_wait4resp = nr_wait4resp - 1
		seq2req[seq] = nil
		req._wcb(c, resp)
	end
	
	local function close()
		local msg = req_head
		while msg do 
			local body = msg.body
			if type(body) == 'userdata' then
				K.putbuf(body)
			end
			msg = msg._wnext
		end

		msg = resp_head
		while msg do 
			local body = msg.body
			if type(body) == 'userdata' then
				K.putbuf(body)
			end
			msg = msg._wnext
		end
        sn2client[c.sn] = false
	end
	
	expire_task = tasklet.start_task(expirereq_taskentry)
	sendmsg_task = tasklet.start_task(sendmsg_taskentry)
	tasklet.start_task(function ()
		while true do 
			local msg, err = K.proto_recvmsg(ch_sock)
			if not msg or  err ~= 0 then
				local sn = c and c.sn or 'UNKNOWN'
				log.error('ctrl-client ', sn, ' recvmsg err=', err, ', msg=', msg)
				ch_sock:close()
				break
			end

			local t = msg.type
			if not t then
				if c then
					handle_response(msg)
				end
				
			elseif t == 'login' then
				handle_login(msg)
				
			elseif c then
				local seq = msg.seq
				local resp = {
					err = 'ok',
					seq = seq,
				}
				c.ts_active = tasklet.now
				
				if t ~= 'heartbeat' then
					local h = reqhandlers[t]
					if h then
						h(c, msg, resp)
					else
						resp.err = 'invalid-type'
					end
				end
				
				if seq >= 0 then
					reply(resp)
				end
			end
			
			if msg.body then
				K.putbuf(msg.body)
			end
		end
		
		if sendmsg_task then
			tasklet.reap_task(sendmsg_task)
		end
		if expire_task then
			tasklet.reap_task(expire_task)
		end
		if c then
			close(c)
		end
	end)
end

local function init()
    conf = V.conf
	require('app').start_tcpserver_task(nil, K.CTRL_PORT, client_loop)
	tasklet.start_task(function ()
		while true do 
			tasklet.sleep(100)
			local now = tasklet.now
			for sn, c in pairs(sn2client) do 
				if c and now - c.ts_active > K.CTRL_SILENT_TIMEDOUT then
					c.ch_sock:close()
					log.info('expired ctrl-client ', sn)
				end
			end
		end
	end)
	local cursor = uci.cursor()
	myip = cursor:get('n2n', 'global', 'sdwan_ip')
	if myip and myip:is_ipv4() and os.fork() == 0 then
		os.closerange(0, 64)
		os.execute('/etc/init.d/n2n restart')
		os.exit(0)
	end
end

return init
