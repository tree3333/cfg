
local n2n = require 'n2n'
local tasklet = require 'tasklet'
local log = require 'log'

local K, V = K, V

local mac2edge = {}
V.mac2edge = mac2edge
local sn2edge = {}
V.sn2edge = sn2edge

local server_fd
local inbuf = buffer.new()
local privbuf = buffer.new()
local outbuf = buffer.new()

local function update_edge(vlanid, mac, sn, nattype, ip, port)
    local edge = mac2edge[mac]
    if edge then
        edge.nr_regsuper = edge.nr_regsuper + 1
        edge.nattype = nattype
        edge.ip = ip
        edge.port = port
        edge.ts_updated = tasklet.now
        edge.sn = sn
        log.debug('updated edge ', sn)
    else
        local edge = {
            mac = mac,
            ip = ip, 
            port = port,
            ts_born = tasklet.now_unix,
            ts_updated = tasklet.now,
            nr_sockerr = 0,   
            nr_regsuper = 1,  
            nr_unipkt = 0,
            nr_multipkt = 0,
            txb_unicast = 0,
            txb_multicast = 0,
            sn = sn,
            nattype = nattype,
        }
        mac2edge[mac] = edge
        sn2edge[sn] = edge
        log.debug('created edge ', sn)
    end
end
    
local function do_unicast(dstmac)
    local edge = mac2edge[dstmac]
    if edge then
        local nsent, err = socket.sendtob(server_fd, edge.ip, edge.port, outbuf)
        if err == 0 then
            edge.txb_unicast = edge.txb_unicast + #outbuf
        else
            log.error(string.format('[unicast] failed to send to %s:%d(%s:%s), err -> %d',
                edge.ip, edge.port, vlanid, edge.mac, err))
            edge.nr_sockerr = edge.nr_sockerr + 1
        end
    end
end

local function do_broadcast(srcmac)
    for mac, edge in pairs(mac2edge) do 
        if mac ~= srcmac then
            local nsent, err = socket.sendtob(server_fd, edge.ip, edge.port, outbuf)
            if err == 0 then
                edge.txb_multicast = edge.txb_multicast + #outbuf
            else
                log.error(string.format('[broadcast] failed to send to %s(%s:%d), err -> %d',
                    edge.sn, edge.ip, edge.port, err))
                edge.nr_sockerr = edge.nr_sockerr + 1
            end
        end
    end
end

local function process(ip, port)
    local ttl, msgtype, flags, vlanid = n2n.decode_common(inbuf, privbuf)

    if msgtype == K.MSG_TYPE_PACKET then
        local srcmac, dstmac, multicast = n2n.decode_packet(inbuf, privbuf, outbuf)
        local edge = srcmac and mac2edge[srcmac]
        if edge then
            n2n.encode_packet(inbuf, ip, port, privbuf, outbuf)
            
            if multicast then
                edge.nr_multipkt = edge.nr_multipkt + 1
                do_broadcast(vlanid, srcmac, outbuf)
            else
                edge.nr_unipkt = edge.nr_unipkt + 1
                do_unicast(dstmac, outbuf)
            end
        end
        
    elseif msgtype == K.MSG_TYPE_REGISTER_SUPER then
        local mac, nattype, token, sn = n2n.decode_regsuper(inbuf, privbuf)
        if mac then
            if token == K.TOKEN then
                n2n.encode_regack(inbuf, ip, port, privbuf, outbuf)
                update_edge(vlanid, mac, sn, nattype, ip, port)
            else
                n2n.encode_regnak(inbuf, K.NAK_AUTH_FAILED, 300, privbuf, outbuf)
                log.warn('NAK(', K.NAK_AUTH_FAILED, '): edgemac=', mac, 
                    ', token=', token, 
                    ', sn=', sn, 
                    ' from ', ip, ':', port)
            end
            socket.sendtob(server_fd, ip, port, outbuf)
        else
            log.warn('illegal REGISTER_SUPER: edgemac=', mac, 
                ', token=', token, 
                ', sn=', sn, 
                ', vlanid=', vlanid, 
                ' from ', ip, ':', port)
        end
    else
        
    end
end

local function init()
	server_fd = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	local err = socket.bind(server_fd, '0.0.0.0', K.SUPERNODE_PORT)
	if err ~= 0 then
		log.fatal('failed to bind on port ', K.SUPERNODE_PORT, ', err -> ', err)
	end
	os.setnonblock(server_fd)
	
	tasklet.add_handler(server_fd, tasklet.EVT_READ, function (fd)
		while true do 
			local nread, ip, port, err = socket.recvfromb(fd, inbuf:rewind())
			if nread == 0 then
				if err ~= 0 then
					log.error('recvfromb err -> ', err)
				end
				break
			end
			process(ip, port)
			privbuf:rewind()
			outbuf:rewind()
		end
	end)
    time.sleep(1)

    tasklet.start_task(function ()
        local rmarr = table.array(16)
        local table = table
        while true do 
            tasklet.sleep(60)
            local now = tasklet.now
            local nr = 0
            for mac, edge in pairs(mac2edge) do 
                if now - edge.ts_updated > K.EDGE_SILENT_TIMEDOUT then
                    nr = nr + 1
                    rmarr[nr] = mac
                    if nr == 16 then
                        break
                    end
                end
            end
            for i = 1, nr do 
                local mac = rmarr[i]
                local edge = mac2edge[mac]
                mac2edge[mac] = nil
                sn2edge[edge.sn] = nil
                log.info('expired edge ', edge.sn)
            end
        end
    end)
end
init()

return dummy
