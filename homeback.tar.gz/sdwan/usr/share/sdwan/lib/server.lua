
K.POOL_MAXNUM = 200
require 'proto'
local conf_init = require 'server.conf'
local ctrl_init = require 'server.ctrl'
local snode_init = require 'server.supernode'
local http_init = require 'server.http'

conf_init()
ctrl_init()
snode_init()
http_init()

