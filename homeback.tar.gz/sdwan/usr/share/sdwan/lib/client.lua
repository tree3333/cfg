

local tasklet = require 'tasklet'
local log = require 'log'
local uci = require 'uci'
local cjson = require 'cjson'
K.POOL_MAXNUM = 20
require 'proto'

local K, V = K, V

local WEBSERVER 
local NEED_FORK = false

local sendmsg_task 
local resp_head, resp_tail = false, false
local req_seq = 2
local req_head, req_tail = false, false
local login_msg = {
	type = 'login',
    sn = K.SERIAL,
    token = 0,
	seq = 0,
    lans = false,
}
local heartbeat_msg = {
	type = 'heartbeat',
	seq = 1,
	_wdeadline = 0,
}

local server_type  -- 0:ip, 1:sn, 2:动态域名
local server_oldip 
local server_ip 

local function getlans()
    local cursor = uci.cursor()
    local t = cursor:get_all('network')
    local ret = {}
    for name, iface in pairs(t) do 
        if name:match('^lan') then
            local ip = iface.ipaddr
            if ip and ip:is_ipv4() then
                table.insert(ret, ip)
            end
        end
    end
    return ret
end

local function enable_n2n(info)
    local cursor = uci.cursor()
    cursor:set('n2n', 'global', 'community', 'sdwan')
    cursor:set('n2n', 'global', 'token', login_msg.token)
    cursor:set('n2n', 'global', 'ipaddr', info.ip)
    cursor:set('n2n', 'global', 'nr_peers', 2)
    cursor:set('n2n', 'global', 'type', info.vlantype)
    cursor:set('n2n', 'global', 'flags', '0')
    cursor:set('n2n', 'global', 'enable', '1')
    cursor:set('n2n', 'global', 'peer1_vlanip', info.core_ip)
    cursor:set('n2n', 'global', 'peer1_lanip', info.core_strlans)
    cursor:set('n2n', 'global', 'sdwan_ip', server_ip)
    cursor:set('n2n', 'global', 'sdwan_err', 'ok')
    cursor:set('n2n', 'global', 'sdwan', K.SERVER)
    cursor:commit('n2n')
    if os.getppid() > 1 then
        if os.fork() > 0 then
            os.exit(0)
        else
            file_put_content('/tmp/' .. require('app').APPNAME .. '.pid', tostring(os.getpid()))
        end
    end
end

local function disable_n2n(err, errobj)
    local cursor = uci.cursor()
    cursor:set('n2n', 'global', 'enable', '0')
    cursor:set('n2n', 'global', 'token', '')
    cursor:delete('n2n', 'global', 'sdwan')
    cursor:delete('n2n', 'global', 'sdwan_ip')
    cursor:set('n2n', 'global', 'sdwan_err', err)
    cursor:set('n2n', 'global', 'sdwan_errobj', errobj or '')
    cursor:commit('n2n')
    os.execute('/etc/init.d/n2n stop')
    log.info('login failed, exit')
    os.exit(0)
end

local function interact_with_server(prevret)
	local ch_sock 
	local dog_hungry = true
    local sendmsg_task = false
	local watchdog_task = false
	local heartbeat_task = false
    local msg, err
	
    if server_type == 0 then
		server_ip = K.SERVER
    else
        server_oldip = server_ip
        local ip
        if server_type == 1 then
            local cmd = 'ajax get "http://' .. WEBSERVER .. '/user.php?s=Agent/Public/getIp&sn=' .. K.SERVER .. '"'
            local ret = require('sh').read(cmd)
            _, ret = pcall(cjson.decode, ret)
            if type(ret) == 'table' and ret.ip then
                ip = ret.ip 
            end
        else
            local ret = netdb.getaddrbyname(K.SERVER)
            ip = ret and ret[1]
        end
        if not ip or not ip:is_ipv4() then
            if prevret or prevret == nil then
                log.error('failed to locate ctrl-server ', K.SERVER)
            end
            return false
        end
        server_ip = ip
	end
	
	ch_sock = tasklet.stream_channel.new()
	if ch_sock:connect(server_ip, K.CTRL_PORT) ~= 0 then
		ch_sock:close()
        if prevret or prevret == nil then
		    log.error('ctrl server unreachable')
        end
		return false
    elseif not prevret then
        log.info('ctrl server connected')
        if server_oldip and server_oldip ~= server_ip then
            local cursor = uci.cursor()
            cursor:set('n2n', 'global', 'sdwan_ip', server_ip)
            cursor:commit('n2n')
            log.info('ctrl-server ip changed from ', server_oldip, ' to ', server_ip, ', restart n2n')
            if os.fork() == 0 then
                os.closerange(0, 16)
                os.execute('/etc/init.d/n2n restart')
                os.exit(0)
            end
        end
	end

    err = K.proto_sendmsg(ch_sock, login_msg)
    if err ~= 0 then
        log.info('ctrl server sendmsg err=', err)
        return false
    end

    msg, err = K.proto_recvmsg(ch_sock)
    if not msg then
        log.info('ctrl server recvmsg err=', err)
        return false
    end

    if msg.seq == 0 then
        if msg.err == 'ok' then
            if msg.vlantype then
                enable_n2n(msg)
                login_msg.lans = false
            end
            if os.fork() == 0 then
                os.closerange(0, 16)
                os.execute('/etc/init.d/n2n restart')
                os.exit(0)
            end
            log.info('login finished')
        else
            disable_n2n(msg.err, msg.errobj)
        end
    else
        log.info('illegal login-response from ctrl server', err)
        return false
    end
        
    local function reply(resp)
        local now = tasklet.now
        resp._wdeadline = now + 3   -- response限定3s内发送完成
        if resp_tail then
            resp_tail._wnext = resp
            resp_tail = resp
        else
            resp_head = resp
            resp_tail = resp
            if sendmsg_task then
                tasklet.kill_task(sendmsg_task)
            end
        end
    end

    local function heartbeat_loop()
        tasklet.sleep(1)
        while true do
            heartbeat_msg._wdeadline = tasklet.now + 30   
            -- 如果已经在队列中则不能再入队列
            if not heartbeat_msg._wnext and req_tail ~= heartbeat_msg then
                if req_tail then
                    req_tail._wnext = heartbeat_msg
                    req_tail = heartbeat_msg
                else
                    req_head, req_tail = heartbeat_msg, heartbeat_msg
                    if sendmsg_task then
                        tasklet.kill_task(sendmsg_task, 1)
                    end
                end
            end
            tasklet.sleep(60)
        end
    end

    local function watchdog_loop()
        while true do
            tasklet.sleep(200)
            if dog_hungry then
                log.error('ctrl heartbeat timed out')
                ch_sock:close()
                break
            end
            dog_hungry = true
        end
        watchdog_task = false
    end

    local function sendmsg_loop()    
        local function send_queue(msg)
            local now = tasklet.now
            local err = 0
            while msg do
                local next = msg._wnext
                local deadline = msg._wdeadline
                local seq = msg.seq
                
                if deadline and now > deadline then
                    local body = msg.body
                    if type(body) == 'userdata' then
                        if body.putc then
                            K.putbuf(body)
                        end
                        msg.body = false
                    end
                else
                    msg._wdeadline = nil
                    msg._wnext = nil
                    err = K.proto_sendmsg(ch_sock, msg)
                    if err ~= 0 then
                        break
                    end
                end
                msg = next
            end
            return err
        end

        local err = 0
        while true do
            local req, resp = req_head, resp_head
            req_head, req_tail = false, false
            resp_head, resp_tail = false, false
            
            if req then
                err = send_queue(req)
                if err ~= 0 then
                    break
                end
            end
            
            if resp then
                err = send_queue(resp)
                if err ~= 0 then
                    break
                end
            elseif not req then
                tasklet.sleep(1)
            end
        end
        ch_sock:close()
        sendmsg_task = false
    end

	-- heartbeat_task: 不能主动退出，只能被reap
	-- watchdog_task: 超时后会主动退出
	-- sendmsg_task: 发送失败后会主动退出
	watchdog_task = tasklet.start_task(watchdog_loop)
	sendmsg_task = tasklet.start_task(sendmsg_loop)
	heartbeat_task = tasklet.start_task(heartbeat_loop)

	local dummy_resp = {}
	while true do
		msg, err = K.proto_recvmsg(ch_sock)
		if not msg or err ~= 0 then	
			log.error('ctrl-server recvmsg error(', err, ') -> ', msg)
			ch_sock:close()
			break
		end
		
		dog_hungry = false
	
		local t, seq = msg.type, msg.seq	
		-- msg是request
		if t then
			local resp = seq and {
				err = 'ok',
				seq = seq,
			} or dummy_resp
            if t == 'getlans' then
                resp.lans = getlans()
            elseif t == 'del' then
                tasklet.start_task(function ()
                    tasklet.sleep(1)
                    disable_n2n('deleted')
                end)
            end
			if seq then
				reply(resp)
			end
			if msg.body then
				K.putbuf(msg.body)
				msg.body = false
			end		
		end
	end
	ch_sock:close()
	
	if sendmsg_task then
		tasklet.reap_task(sendmsg_task)
		sendmsg_task = false
	end
	if watchdog_task then
		tasklet.reap_task(watchdog_task)
	end
	tasklet.reap_task(heartbeat_task)
    return true
end

local function init()
    if K.SERVER:is_ipv4() then
        server_type = 0
    elseif K.SERVER:find('%.') then
        server_type = 2
    else
        server_type = 1
    end
    local cursor = uci.cursor()

    WEBSERVER = cursor:get('webmgmt', 'global', 'cloud_webserver')
    if not WEBSERVER or #WEBSERVER < 5 then
        local vendor_class = cursor:get("product_params", "vendor", "oemclass")	
        vendor_class = vendor_class and vendor_class:match('([%w%-%_]+)') or 'GOCLOUD'
        WEBSERVER = vendor_class == 'GOCLOUD'  and 'agent.gocloud.cn' or 'daili.tg-net.cn'
    else
        WEBSERVER = WEBSERVER:match('(%S+)')
    end    

    if K.SECEDE then
        login_msg.secede = true 
    else
        local enable = cursor:get('n2n', 'global', 'enable')
        if enable ~= '1' then
            login_msg.lans = getlans()
        end
        if K.TOKEN then
            NEED_FORK = true
            login_msg.token = K.TOKEN
        else    
            login_msg.token = cursor:get('n2n', 'global', 'token')
            K.TOKEN = login_msg.token
        end
    end

	tasklet.start_task(function ()
        local prevret
        log.info('interacting with ctrl-server ... ')
        prevret = interact_with_server(prevret)
        if not prevret and (os.getppid() > 1 or K.SECEDE) then
            local cursor = uci.cursor()
            cursor:set('n2n', 'global', 'sdwan_err', 'servererr')
            cursor:commit('n2n')
            os.exit(1)
        end
        if K.SECEDE then
            os.exit(0)
        end
		while true do 
            tasklet.sleep(prevret and 5 or 60)
            prevret = interact_with_server(prevret)
		end
	end)
end

init()
