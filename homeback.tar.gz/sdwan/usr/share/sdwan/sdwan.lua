#!/usr/bin/lua 

require 'std'

local TOP_DIR = fs.dirname(fs.realpath(arg[0])) .. '/' 
package.path = package.path .. ';' .. TOP_DIR .. 'lib/?.lua'

local tasklet = require 'tasklet'
local log = require 'log'
local cjson = require 'cjson'
local sh = require 'sh'
local uci = require 'uci'
require 'tasklet.channel.message'
require 'tasklet.util'

local APPNAME = 'sdwan'
local K = {
	MAX_NRDEVS = 250, 

	SERVER = false,
	TOKEN = false,

	SUPERNODE_PORT = 17217,  -- udp
	CTRL_PORT = 17217,  -- tcp
	HTTP_PORT = 17218,  -- tcp
	
	CTRL_REQUEST_TIMEDOUT = 5,
	CTRL_SILENT_TIMEDOUT = 120,
	EDGE_SILENT_TIMEDOUT = 300,
	
	MSG_TYPE_REGISTER_SUPER = 5,
	MSG_TYPE_PACKET = 3,

	VLAN_KLASS_STAR = 1,  -- 星型
	VLAN_KLASS_SYM = 2,   -- 对称型
	VLAN_KLASS_RSTAR = 3, -- 反向星型
	VLAN_KLASS_DSTAR = 4, -- 双向星型
	
	NAK_AUTH_FAILED = 2,
}
local V = {
}
local R = {}
_G.K = K
_G.V = V
_G.R = R

local function init_K()
	local vendor, model, serial, stdpt
	local buf, err = file_get_content('/etc/product_info', tmpbuf:rewind())
	while true do 
		local line = buf:getline()
		if not line then
			break
		end
		local k, v = line:match('([%w%_%-]+)=(.+)')
		if k and v then
			if k == 'PRODUCT_VENDOR' then
				vendor = v
			elseif k == 'PRODUCT_NAME' then
				model = v
			elseif k == 'SERIAL_NUMBER' then
				serial = v
			elseif k == 'PRODUCT_STD_NAME' then
				stdpt = v
			end
		end
	end
	if vendor and model and serial and #serial > 5 then
		K.VENDOR = vendor
		K.MODEL = model
		K.SERIAL = serial
		K.STDPT = stdpt
	else
		log.fatal('failed to load system info(version/model/serial/vendor)')
	end
end


local function main(ARGV)
	local opts = getopt(ARGV, 'dhs:t:', {
		'debug',
		'help',
		'server=',
		'token=',
		'secede',
	})
	local usage = [[
USAGE (client mode)
	sdwan --server=<server_ip_or_serial> [--token=<token>] [--secede]
or (auto mode) 
	sdwan 
]]
	if not opts then
		print(usage)
		os.exit(1)
	end
	
	if opts.h or opts.help then
		print(usage)
		os.exit(0)
	end

	if opts.server then
		K.SERVER = opts.server
		if opts.token then
			K.TOKEN = opts.token
			opts.f = true  -- foreground
		end
	end
	if opts.secede then
		K.SECEDE = true
	end
	
	local app = require 'app'
	opts.o = '/tmp/' .. APPNAME .. '.log'

	app.APPNAME = APPNAME		
	app.run(opts, function ()
		init_K()
		local server = K.SERVER
		if not server then
			local cursor = uci.cursor()
			server = cursor:get('n2n', 'global', 'sdwan')
			if not server or #server < 3 then
				log.fatal('invalid config n2n.sdwan.sdwan')
				os.exit(1)
			end
			K.SERVER = server
		end
		if server == 'myself' then
			require 'server'
		else
			require 'client'
		end
		file_put_content('/tmp/' .. APPNAME .. '.pid', tostring(os.getpid()))
	end)
	os.exit(0)
end

main(arg)

