#!/bin/sh
usage(){
    echo "Usage: ./do.sh install|i uninstall|u"
}
install(){
    rm -f ./install.log
    for item in `find ./`;do
        if [[ -d $item ]] && [[ ! -d "/$item" ]];then
           echo "/$item" >> ./install.log
        fi
    done
    echo "Install succeed, you can uninstall by using ./do.sh u"
}
uninstall(){
    for item in `cat ./install.log`;do
        echo "rm -rf $item"
    done
    rm -f ./install.log
    echo "Uninstall succeed, you can install again by using ./do.sh i"
}
case $1 in             
install|i)                            
    install 
    ;;                                              
uninstall|u)                    
    uninstall                              
    ;;      
*)       
    usage   
    ;;                  
esac 
