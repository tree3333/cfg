#!/bin/sh
export PATH='/usr/sbin:/usr/bin:/sbin:/bin'

# Paraments
resub=1
push1="1"				# Push online devices
push_ddns="1"			# Push ddns message
serverchan_enable="1"	# Enable ServerChan
serverchan_sckey="SCT147551TVvUs26O8FhaVB85vkTL6qGl0"		# ServerChan api key


touch /tmp/tmp/lastIPAddress
[ ! -s /tmp/tmp/lastIPAddress ] && echo "爷刚启动！" > /tmp/tmp/lastIPAddress

touch /tmp/tmp/pushDevice
[ ! -s /tmp/tmp/pushDevice ] && echo "$push1" > /tmp/tmp/pushDevice

# Get wan IP
# Check curl exist, if not, use wget
getIpAddress() {
    curltest=`which curl`
    if [ -z "$curltest" ] || [ ! -s "`which curl`" ] ; then
        wget --no-check-certificate --quiet --output-document=- "http://members.3322.org/dyndns/getip"
    else
        curl -k -s "http://members.3322.org/dyndns/getip"
    fi
}
# load last IP
lastIPAddress() {
        inter="/tmp/tmp/lastIPAddress"
        cat $inter
}



# Get online devices
test(){
	alias=`cat /tmp/dhcp.leases`
	cat /proc/net/arp | sed 's/(//;s/)//' | while read -r IP HW FLAGS MAC MASK DEVICE
	do
	    #echo $DEVICE
        if [ $DEVICE == "br-lan" ]; then
		NAME=`echo "$alias" | awk '/'$MAC'\ '$IP'/{print $4}'`
        echo $NAME $IP >> /tmp/tmp/newhostname.txt
        #echo $NAME $IP
		fi
	done
}

while [ "$serverchan_enable" == "1" ];
do
curltest=`which curl`
if [ -z "$curltest" ] ; then
    wget --continue --no-check-certificate  -q -T 10 http://www.baidu.com
	[ "$?" == "0" ] && check=200 || check=404
else
    check=`curl -k -s -w "%{http_code}" "http://www.baidu.com" -o /dev/null`
fi

if [ "$check" == "200" ] ; then
hostIP=$(getIpAddress)
lastIP=$(lastIPAddress)

if [ "$lastIP" != "$hostIP" ] && [ ! -z "$hostIP" ] ; then
	sleep 60
    # Check again
	hostIP=$(getIpAddress)
    lastIP=$(lastIPAddress)
 fi

if [ "$lastIP" != "$hostIP" ] && [ ! -z "$hostIP" ] ; then
    logger -t "公网IP变动" "目前 IP: ${hostIP}"
    logger -t "公网IP变动" "上次 IP: ${lastIP}"
	if [ "$?" == "0" ] ; then
		if [ "$push_ddns" = "1" ] ; then
			curl -s "http://sc.ftqq.com/$serverchan_sckey.send?text=703N的ip更新啦" -d "&desp=${hostIP}" &
			logger -t "wechat push" "IP: ${hostIP} pushed"
		fi
		echo -n $hostIP > /tmp/tmp/lastIPAddress
	fi
fi

if [ `cat /tmp/tmp/pushDevice` = "1" ] ; then
    # 设备上、下线提醒
    # 获取接入设备名称
    touch /tmp/tmp/newhostname.txt
    echo "接入设备名称" > /tmp/tmp/newhostname.txt	
    # 当前所有接入设备
	test
	# 读取已在线设备名称
    touch /tmp/tmp/hostname_online.txt
    [ ! -s /tmp/tmp/hostname_online.txt ] && echo "接入设备名称" > /tmp/tmp/hostname_online.txt
    # 上线
    awk 'NR==FNR{a[$0]++} NR>FNR&&a[$0]' /tmp/tmp/hostname_online.txt /tmp/tmp/newhostname.txt > /tmp/tmp/newhostname_same_online.txt
    awk 'NR==FNR{a[$0]++} NR>FNR&&!a[$0]' /tmp/tmp/newhostname_same_online.txt /tmp/tmp/newhostname.txt > /tmp/tmp/newhostname_uniqe_online.txt
    if [ -s "/tmp/tmp/newhostname_uniqe_online.txt" ] ; then
		content=`cat /tmp/tmp/newhostname_uniqe_online.txt | grep -v "^$"`
		curl -s "http://sc.ftqq.com/$serverchan_sckey.send?text=703N有设备上线啦" -d "&desp=${content}" &
		logger -t "wechat push" "设备上线: ${content} pushed"
		cat /tmp/tmp/newhostname_uniqe_online.txt | grep -v "^$" >> /tmp/tmp/hostname_online.txt
    fi
    # 下线
    awk 'NR==FNR{a[$0]++} NR>FNR&&!a[$0]' /tmp/tmp/newhostname.txt /tmp/tmp/hostname_online.txt > /tmp/tmp/newhostname_uniqe_offline.txt
    if [ -s "/tmp/tmp/newhostname_uniqe_offline.txt" ] ; then
       content=`cat /tmp/tmp/newhostname_uniqe_offline.txt | grep -v "^$"`
       curl -s "http://sc.ftqq.com/$serverchan_sckey.send?text=703N有设备下线啦" -d "&desp=${content}" &
       logger -t "wechat push" "设备下线: ${content} pushed"
       cat /tmp/tmp/newhostname.txt | grep -v "^$" > /tmp/tmp/hostname_online.txt
    fi
fi
resub=`expr $resub + 1`
[ "$resub" -gt 360 ] && resub=1
else
logger -t "server chan" "Check network failed."
resub=1
fi
sleep 100
continue
done
